// The current public homepage stays on GitHub Pages, where the release is verified.
// Private account, PIN and camera routes retain the existing same-origin panel.
// No tracking, authentication or camera commands are issued here.
(() => {
  if (window.__hsDesktopOAuthReturning) return;
  const params = new URLSearchParams(location.search);
  const fragment = new URLSearchParams(location.hash.replace(/^#/, ''));
  const privateLink = params.get('section') === 'recordings' || params.get('wroc') === 'nagrania' || params.has('auth') || params.has('code') || ['owner', 'wlasciciel'].includes(params.get('panel')) ||
    params.get('app') === 'android' || /^cam-[a-f0-9]{32}$/.test(params.get('odbiorca') || '') ||
    location.hash === '#nadaj' || fragment.has('access_token') || fragment.has('error') ||
    fragment.get('type') === 'recovery';
  const native = window.__HOME_SECURITY_DESKTOP__ === true || !!window.chrome?.webview;
  // Public home stays public even with saved device state or installed PWA.
  // Autoryzacja, odbiorcy i linki do nagran nadal wymagaja panel.html.
  if (params.get("app") === "mobile-home" && !privateLink && !native) return;
  if (!privateLink && !native) {
    const topics={"mozliwosci":"mozliwosci.html","jak-dziala":"jak-dziala.html","specyfikacja":"wymagania.html","stan-projektu":"stan-projektu.html","przygotowanie":"przygotowanie.html","zobacz-panel":"mozliwosci.html","galeria":"galeria.html","faq":"pytania.html","asystent":"pytania.html","w-praktyce":"jak-dziala.html","zastosowania":"mozliwosci.html","prywatnosc":"jak-dziala.html"};
    const topic=topics[location.hash.slice(1)];
    if(topic){const destination=new URL(topic,location.href);destination.search=location.search;location.replace(destination.href);return;}
    // Full public content is already in this HTML. Never redirect to a stale mirror.
    // Local support and internal anchor links stay available.
    return;
  }
  const target = new URL('./panel.html', location.href);
  target.search = location.search;
  target.hash = location.hash;
  location.replace(target.href);
})();
